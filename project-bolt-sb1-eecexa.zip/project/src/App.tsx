import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Models from './components/Models';
import Bespoke from './components/Bespoke';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <Models />
      <Bespoke />
      <Footer />
    </div>
  );
}

export default App;