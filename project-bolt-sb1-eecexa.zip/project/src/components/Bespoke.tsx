import React from 'react';

export default function Bespoke() {
  return (
    <section id="bespoke" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-serif text-black mb-6">Bespoke is Rolls-Royce</h2>
            <p className="text-gray-600 mb-8">
              Your Rolls-Royce is a canvas for your imagination. Our master craftspeople 
              will bring your vision to life, creating a motor car that is uniquely yours.
            </p>
            <div className="space-y-4">
              {['Custom Paint', 'Exclusive Materials', 'Personal Touches', 'Unique Features'].map((feature) => (
                <div key={feature} className="flex items-center">
                  <div className="w-2 h-2 bg-black rounded-full mr-3" />
                  <span className="text-gray-800">{feature}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1635770310392-f1ae37929ee1?auto=format&fit=crop&q=80" 
              alt="Bespoke Craftsmanship"
              className="w-full h-[600px] object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}