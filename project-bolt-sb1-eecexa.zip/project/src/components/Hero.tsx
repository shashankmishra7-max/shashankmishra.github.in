import React from 'react';

export default function Hero() {
  return (
    <div className="relative h-screen">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1631295868223-63265b40d9e4?auto=format&fit=crop&q=80")'
        }}
      >
        <div className="absolute inset-0 bg-black/30" />
      </div>
      
      <div className="relative h-full flex items-center justify-center text-center">
        <div className="max-w-4xl px-4">
          <h1 className="text-5xl md:text-7xl font-serif text-white mb-6">
            PERFECTION IS IN EVERY DETAIL
          </h1>
          <p className="text-xl text-gray-200 mb-8">
            Experience unparalleled luxury and craftsmanship
          </p>
          <button className="bg-white text-black px-8 py-3 text-lg font-medium hover:bg-gray-200 transition-colors">
            Explore Our Models
          </button>
        </div>
      </div>
    </div>
  );
}