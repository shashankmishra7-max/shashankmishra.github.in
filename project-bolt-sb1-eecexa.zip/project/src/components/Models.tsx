import React from 'react';

const models = [
  {
    name: 'Phantom',
    description: 'The pinnacle of luxury',
    image: 'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&q=80'
  },
  {
    name: 'Ghost',
    description: 'Power meets sophistication',
    image: 'https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&q=80'
  },
  {
    name: 'Cullinan',
    description: 'Effortless everywhere',
    image: 'https://images.unsplash.com/photo-1619405399517-d7fce0f13302?auto=format&fit=crop&q=80'
  }
];

export default function Models() {
  return (
    <section id="models" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-serif text-white text-center mb-16">Our Models</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {models.map((model) => (
            <div key={model.name} className="group relative overflow-hidden">
              <div className="aspect-w-16 aspect-h-9 overflow-hidden">
                <img 
                  src={model.image} 
                  alt={model.name}
                  className="w-full h-[400px] object-cover transform group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                <div>
                  <h3 className="text-2xl font-serif text-white mb-2">{model.name}</h3>
                  <p className="text-gray-300">{model.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}