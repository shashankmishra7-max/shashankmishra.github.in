import React, { useState } from 'react';
import { Menu, X, Search, User } from 'lucide-react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed w-full bg-black/80 backdrop-blur-md z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <span className="text-white text-2xl font-serif">ROLLS-ROYCE</span>
          </div>
          
          <div className="hidden md:block">
            <div className="flex items-center space-x-8">
              <a href="#models" className="text-gray-300 hover:text-white transition-colors">Models</a>
              <a href="#bespoke" className="text-gray-300 hover:text-white transition-colors">Bespoke</a>
              <a href="#ownership" className="text-gray-300 hover:text-white transition-colors">Ownership</a>
              <a href="#heritage" className="text-gray-300 hover:text-white transition-colors">Heritage</a>
              <div className="flex items-center space-x-4 ml-4">
                <Search className="w-5 h-5 text-gray-300 hover:text-white cursor-pointer" />
                <User className="w-5 h-5 text-gray-300 hover:text-white cursor-pointer" />
              </div>
            </div>
          </div>
          
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? (
                <X className="h-6 w-6 text-white" />
              ) : (
                <Menu className="h-6 w-6 text-white" />
              )}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-black">
            <a href="#models" className="block px-3 py-2 text-gray-300 hover:text-white">Models</a>
            <a href="#bespoke" className="block px-3 py-2 text-gray-300 hover:text-white">Bespoke</a>
            <a href="#ownership" className="block px-3 py-2 text-gray-300 hover:text-white">Ownership</a>
            <a href="#heritage" className="block px-3 py-2 text-gray-300 hover:text-white">Heritage</a>
          </div>
        </div>
      )}
    </nav>
  );
}